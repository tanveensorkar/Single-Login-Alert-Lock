<?php
/**
 * Plugin Name: Single Login Alert Lock
 * Description: Restrict each user to one device login. Deny login from another device and show warning.
 * Version: 1.0
 * Author: Your Name
 */

define('SLAL_SESSION_EXPIRY', 3600); // 1 hour session validity

add_action('init', 'slal_check_existing_session');
add_action('wp_login', 'slal_handle_login_session', 10, 2);
add_action('wp_logout', 'slal_clear_login_session');

function slal_check_existing_session() {
    if (!is_user_logged_in() || get_option('slal_enabled') !== '1') return;

    $user = wp_get_current_user();
    $session = get_user_meta($user->ID, '_slal_session_data', true);
    $current_ip = $_SERVER['REMOTE_ADDR'];
    $cookie_token = $_COOKIE['slal_token'] ?? '';

    if ($session) {
        $expired = (time() - $session['time']) > SLAL_SESSION_EXPIRY;
        $same_ip = $session['ip'] === $current_ip;
        $same_token = $session['token'] === $cookie_token;

        if (!$expired && (!$same_ip || !$same_token)) {
            wp_logout();
            wp_redirect(add_query_arg('slal_alert', '1', wp_login_url()));
            exit;
        }
    }
}

function slal_handle_login_session($user_login, $user) {
    if (get_option('slal_enabled') !== '1') return;

    $existing_session = get_user_meta($user->ID, '_slal_session_data', true);
    $current_ip = $_SERVER['REMOTE_ADDR'];
    $token = bin2hex(random_bytes(16));

    if ($existing_session && (time() - $existing_session['time']) < SLAL_SESSION_EXPIRY) {
        if ($existing_session['ip'] !== $current_ip) {
            wp_logout();
            wp_redirect(add_query_arg('slal_alert', '1', wp_login_url()));
            exit;
        }
    }

    // Save session
    $data = [
        'ip' => $current_ip,
        'token' => $token,
        'time' => time()
    ];
    update_user_meta($user->ID, '_slal_session_data', $data);
    setcookie('slal_token', $token, time() + SLAL_SESSION_EXPIRY, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true);
}

function slal_clear_login_session() {
    $user = wp_get_current_user();
    if ($user && $user->ID) {
        delete_user_meta($user->ID, '_slal_session_data');
    }
    setcookie('slal_token', '', time() - 3600, COOKIEPATH, COOKIE_DOMAIN);
}

add_action('login_message', function($message) {
    if (isset($_GET['slal_alert']) && $_GET['slal_alert'] === '1') {
        $message .= '<div style="border: 2px solid red; padding: 10px; margin-top: 10px; background: #fff3f3; color: red;">
            <strong>Warning:</strong> You are already logged in on another device.<br>
            <strong>Next time you try this, we may disable your account.</strong>
        </div>';
    }
    return $message;
});

// Admin Settings
add_action('admin_menu', function () {
    add_options_page('Single Login Alert Lock', 'Single Login Alert Lock', 'manage_options', 'slal-settings', 'slal_settings_page');
});
add_action('admin_init', function () {
    register_setting('slal_settings_group', 'slal_enabled');
});

function slal_settings_page() {
    $enabled = get_option('slal_enabled', '0');
    ?>
    <div class="wrap">
        <h1>Single Login Alert Lock</h1>
        <form method="post" action="options.php">
            <?php settings_fields('slal_settings_group'); ?>
            <table class="form-table">
                <tr>
                    <th scope="row">Enable Lock</th>
                    <td>
                        <select name="slal_enabled">
                            <option value="0" <?php selected($enabled, '0'); ?>>OFF</option>
                            <option value="1" <?php selected($enabled, '1'); ?>>ON</option>
                        </select>
                        <p class="description">Prevents multiple logins and shows warning if attempted.</p>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

register_activation_hook(__FILE__, function () {
    if (!wp_next_scheduled('slal_cleanup_event')) {
        wp_schedule_event(time(), 'hourly', 'slal_cleanup_event');
    }
});
register_deactivation_hook(__FILE__, function () {
    wp_clear_scheduled_hook('slal_cleanup_event');
});
add_action('slal_cleanup_event', function () {
    $users = get_users(['meta_key' => '_slal_session_data', 'fields' => 'ID']);
    foreach ($users as $user_id) {
        $session = get_user_meta($user_id, '_slal_session_data', true);
        if ($session && (time() - $session['time']) > SLAL_SESSION_EXPIRY) {
            delete_user_meta($user_id, '_slal_session_data');
        }
    }
});
